// JavaScript code for the sample website

// Function to change the color of the header on mouseover
function changeHeaderColor() {
    const header = document.querySelector('header');
    header.style.backgroundColor = '#555';
}

// Function to change the color of the header back to its original color on mouseout
function resetHeaderColor() {
    const header = document.querySelector('header');
    header.style.backgroundColor = '#333';
}

// Event listeners to trigger the color change functions
const header = document.querySelector('header');
header.addEventListener('mouseover', changeHeaderColor);
header.addEventListener('mouseout', resetHeaderColor);

// Function to display an alert when a navigation link is clicked
function showAlert() {
    alert('You clicked a navigation link!');
}

// Event listeners for navigation links to trigger the alert function
const navLinks = document.querySelectorAll('nav a');
navLinks.forEach(link => {
    link.addEventListener('click', showAlert);
});
